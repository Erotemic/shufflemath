git-well incremental source patch
=================================

This is not a standalone source archive. It requires the exact compatible
base archive named below.

Required base archive: shufflemath-source-2026-10-04T083916-5-65e4b126d14e.tar.gz
Required base archive SHA-256: c3a1ea6ed89a760ed2d949e9e1bdebed8d9ce24c06435321a3c9ba2e2ac8b8d7
Base commit: 65e4b126d14ef40bde867758b7d36761f7de858b
Target commit: b69d00a7c1e849a557677eeaa47172a839b9a3e3

Standalone application (git-well is NOT required)
-------------------------------------------------

Requirements:
  - Python 3.10 or newer
  - git on PATH

1. Extract this patch archive.
2. From the extracted patch directory, run:

   python APPLY_SOURCE_PATCH.py /path/to/shufflemath-source-2026-10-04T083916-5-65e4b126d14e.tar.gz /path/to/output

The output directory must be empty or not yet exist. The script verifies
the exact base SHA-256 and every Git repository HEAD before and after
application, including Git-bearing submodules represented by this patch.
It prints the reconstructed target source root on success.

Installed git-well API
----------------------

The same application implementation is available as:

   git_well.archive_source.apply_source_patch(
       base_archive, patch_archive, output_directory)

Do not manually merge overlay/ into the base archive. Use the script or
the API so base identity, Git object deltas, deletions, and submodules are all
handled and verified together.
